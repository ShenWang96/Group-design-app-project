<?php
echo date("y-m-d H:i:s EST");
?>