
		<form method='post'action='../garage/index.php'>
		  <div class="form-group">
			<label for="exampleInputEmail1">Username</label>
			<input name = 'username'type="username" class="form-control" id="exampleInputEmail1" >
		  </div>
		  <div class="form-group">
			<label for="exampleInputPassword1">Password</label>
			<input name = 'password'type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
		  </div>		 
		  <button type="submit" name='login' class="btn btn-lg btn-primary">Login</button>
		</form>
	   
